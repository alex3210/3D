var canvas;
var gl;

var program ;

//var near = -100;
var near = 0.1;
var far = 100;


var left = -20.0;
var right = 20.0;
var ytop =20.0;
var bottom = -20.0;


var lightPosition2 = vec4(100.0, 100.0, 100.0, 1.0 );
var lightPosition = vec4(0.0, 0.0, 100.0, 1.0 );

var lightAmbient = vec4(0.2, 0.2, 0.2, 1.0 );
var lightDiffuse = vec4( 1.0, 1.0, 1.0, 1.0 );
var lightSpecular = vec4( 1.0, 1.0, 1.0, 1.0 );

var materialAmbient = vec4( 1.0, 0.0, 1.0, 1.0 );
var materialDiffuse = vec4( 1.0, 0.8, 0.0, 1.0 );
var materialSpecular = vec4( 0.4, 0.4, 0.4, 1.0 );
var materialShininess = 30.0;


var ambientColor, diffuseColor, specularColor;

var modelMatrix, viewMatrix ;
var modelViewMatrix, projectionMatrix, normalMatrix;
var modelViewMatrixLoc, projectionMatrixLoc, normalMatrixLoc;

var eye;
var at = vec3(0,0,0);
var up = vec3(0.0, 1.0, 0.0);

var RX = 0 ;
var RY = 0 ;
var RZ = 0 ;

var MS = [] ; // The modeling matrix stack
var TIME = 0.0 ; // Realtime
var TIME = 0.0 ; // Realtime
var resetTimerFlag = true ;
var animFlag = false ;
var prevTime = 0.0 ;
var useTextures = 1 ;

var count = 0;
var timePass = 0;
var startTime = TIME;

// ------------ Images for textures stuff --------------
var texSize = 64;

var image1 = new Array()
for (var i =0; i<texSize; i++)  image1[i] = new Array();
for (var i =0; i<texSize; i++)
for ( var j = 0; j < texSize; j++)
image1[i][j] = new Float32Array(4);
for (var i =0; i<texSize; i++) for (var j=0; j<texSize; j++) {
    var c = (((i & 0x8) == 0) ^ ((j & 0x8)  == 0));
    image1[i][j] = [c, c, c, 1];
}

// Convert floats to ubytes for texture

var image2 = new Uint8Array(4*texSize*texSize);

for ( var i = 0; i < texSize; i++ )
for ( var j = 0; j < texSize; j++ )
for(var k =0; k<4; k++)
image2[4*texSize*i+4*j+k] = 255*image1[i][j][k];


var textureArray = [] ;



function isLoaded(im) {
    if (im.complete) {
        console.log("loaded") ;
        return true ;
    }
    else {
        console.log("still not loaded!!!!") ;
        return false ;
    }
}

function loadFileTexture(tex, filename)
{
    tex.textureWebGL  = gl.createTexture();
    tex.image = new Image();
    tex.image.src = filename ;
    tex.isTextureReady = false ;
    tex.image.onload = function() { handleTextureLoaded(tex); }
    // The image is going to be loaded asyncronously (lazy) which could be
    // after the program continues to the next functions. OUCH!
}

function loadImageTexture(tex, image) {
    tex.textureWebGL  = gl.createTexture();
    tex.image = new Image();
    //tex.image.src = "CheckerBoard-from-Memory" ;
    
    gl.bindTexture( gl.TEXTURE_2D, tex.textureWebGL );
    //gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, texSize, texSize, 0,
                  gl.RGBA, gl.UNSIGNED_BYTE, image);
    gl.generateMipmap( gl.TEXTURE_2D );
    gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER,
                     gl.NEAREST_MIPMAP_LINEAR );
    gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST );
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); //Prevents s-coordinate wrapping (repeating)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); //Prevents t-coordinate wrapping (repeating)
    gl.bindTexture(gl.TEXTURE_2D, null);

    tex.isTextureReady = true ;

}

function initTextures() {
    
    textureArray.push({}) ;
    loadFileTexture(textureArray[textureArray.length-1],"roof.png") ;
    
    //textureArray.push({}) ;
    //loadFileTexture(textureArray[textureArray.length-1],"cubetexture.png") ;
    
    //textureArray.push({}) ;
    //loadImageTexture(textureArray[textureArray.length-1],image2) ;
    
    //textureArray.push({}) ;
    //loadFileTexture(textureArray[textureArray.length-1],"trucktexture.jpg") ;
}


function handleTextureLoaded(textureObj) {
    gl.bindTexture(gl.TEXTURE_2D, textureObj.textureWebGL);
	gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true); // otherwise the image would be flipped upsdide down
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, textureObj.image);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_NEAREST);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); //Prevents s-coordinate wrapping (repeating)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); //Prevents t-coordinate wrapping (repeating)
    gl.bindTexture(gl.TEXTURE_2D, null);
    console.log(textureObj.image.src) ;
    
    textureObj.isTextureReady = true ;
}

//----------------------------------------------------------------

function setColor(c)
{
    ambientProduct = mult(lightAmbient, c);
    diffuseProduct = mult(lightDiffuse, c);
    specularProduct = mult(lightSpecular, materialSpecular);
    
    gl.uniform4fv( gl.getUniformLocation(program,
                                         "ambientProduct"),flatten(ambientProduct) );
    gl.uniform4fv( gl.getUniformLocation(program,
                                         "diffuseProduct"),flatten(diffuseProduct) );
    gl.uniform4fv( gl.getUniformLocation(program,
                                         "specularProduct"),flatten(specularProduct) );
    gl.uniform4fv( gl.getUniformLocation(program,
                                         "lightPosition"),flatten(lightPosition) );
    gl.uniform1f( gl.getUniformLocation(program, 
                                        "shininess"),materialShininess );
}

function toggleTextures() {
    useTextures = 1 - useTextures ;
    gl.uniform1i( gl.getUniformLocation(program, "useTextures"), 0);
}

function waitForTextures1(tex) {
    setTimeout( function() {
    console.log("Waiting for: "+ tex.image.src) ;
    wtime = (new Date()).getTime() ;
    if( !tex.isTextureReady )
    {
        console.log(wtime + " not ready yet") ;
        waitForTextures1(tex) ;
    }
    else
    {
        console.log("ready to render") ;
        window.requestAnimFrame(render);
    }
               },5) ;
    
}

// Takes an array of textures and calls render if the textures are created
function waitForTextures(texs) {
    setTimeout( function() {
               var n = 0 ;
               for ( var i = 0 ; i < texs.length ; i++ )
               {
                    console.log("boo"+texs[i].image.src) ;
                    n = n+texs[i].isTextureReady ;
               }
               wtime = (new Date()).getTime() ;
               if( n != texs.length )
               {
               console.log(wtime + " not ready yet") ;
               waitForTextures(texs) ;
               }
               else
               {
               console.log("ready to render") ;
               window.requestAnimFrame(render);
               }
               },5) ;
    
}

window.onload = function init() {

    canvas = document.getElementById( "gl-canvas" );
    
    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { alert( "WebGL isn't available" ); }

    gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 0.5, 0.5, 1.0, 1.0 );
    
    gl.enable(gl.DEPTH_TEST);

    //
    //  Load shaders and initialize attribute buffers
    //
    program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram( program );
    
 
    // Load canonical objects and their attributes
    Cube.init(program);
    Cylinder.init(36,program);
    Cone.init(36,program) ;
    Sphere.init(36,program) ;

    gl.uniform1i( gl.getUniformLocation(program, "useTextures"), useTextures );

    // record the locations of the matrices that are used in the shaders
    modelViewMatrixLoc = gl.getUniformLocation( program, "modelViewMatrix" );
    normalMatrixLoc = gl.getUniformLocation( program, "normalMatrix" );
    projectionMatrixLoc = gl.getUniformLocation( program, "projectionMatrix" );
    
    // set a default material
    setColor(materialDiffuse) ;
    
  
    
    // set the callbacks for the UI elements
    document.getElementById("sliderXi").onchange = function() {
        RX = this.value ;
        window.requestAnimFrame(render);
    };
    document.getElementById("sliderYi").onchange = function() {
        RY = this.value;
        window.requestAnimFrame(render);
    };
    document.getElementById("sliderZi").onchange = function() {
        RZ =  this.value;
        window.requestAnimFrame(render);
    };
    
    document.getElementById("animToggleButton").onclick = function() {
        if( animFlag ) {
            animFlag = false;
        }
        else {
            animFlag = true  ;
            resetTimerFlag = true ;
            window.requestAnimFrame(render);
        }
    };
    
    document.getElementById("textureToggleButton").onclick = function() {
        toggleTextures() ;
        window.requestAnimFrame(render);
    };

    var controller = new CameraController(canvas);
    controller.onchange = function(xRot,yRot) {
        RX = xRot ;
        RY = yRot ;
        window.requestAnimFrame(render); };
    
    // load and initialize the textures
    initTextures() ;
    
    // Recursive wait for the textures to load
    waitForTextures(textureArray) ;
    //setTimeout (render, 100) ;
    
}

// Sets the modelview and normal matrix in the shaders
function setMV() {
    modelViewMatrix = mult(viewMatrix,modelMatrix) ;
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix) );
    normalMatrix = inverseTranspose(modelViewMatrix) ;
    gl.uniformMatrix4fv(normalMatrixLoc, false, flatten(normalMatrix) );
}

// Sets the projection, modelview and normal matrix in the shaders
function setAllMatrices() {
    gl.uniformMatrix4fv(projectionMatrixLoc, false, flatten(projectionMatrix) );
    setMV() ;
    
}

// Draws a 2x2x2 cube center at the origin
// Sets the modelview matrix and the normal matrix of the global program
function drawCube() {
    setMV() ;
    Cube.draw() ;
}

// Draws a sphere centered at the origin of radius 1.0.
// Sets the modelview matrix and the normal matrix of the global program
function drawSphere() {
    setMV() ;
    Sphere.draw() ;
}
// Draws a cylinder along z of height 1 centered at the origin
// and radius 0.5.
// Sets the modelview matrix and the normal matrix of the global program
function drawCylinder() {
    setMV() ;
    Cylinder.draw() ;
}

// Draws a cone along z of height 1 centered at the origin
// and base radius 1.0.
// Sets the modelview matrix and the normal matrix of the global program
function drawCone() {
    setMV() ;
    Cone.draw() ;
}

// Post multiples the modelview matrix with a translation matrix
// and replaces the modelview matrix with the result
function gTranslate(x,y,z) {
    modelMatrix = mult(modelMatrix,translate([x,y,z])) ;
}

// Post multiples the modelview matrix with a rotation matrix
// and replaces the modelview matrix with the result
function gRotate(theta,x,y,z) {
    modelMatrix = mult(modelMatrix,rotate(theta,[x,y,z])) ;
}

// Post multiples the modelview matrix with a scaling matrix
// and replaces the modelview matrix with the result
function gScale(sx,sy,sz) {
    modelMatrix = mult(modelMatrix,scale(sx,sy,sz)) ;
}

// Pops MS and stores the result as the current modelMatrix
function gPop() {
    modelMatrix = MS.pop() ;
}

// pushes the current modelMatrix in the stack MS
function gPush() {
    MS.push(modelMatrix) ;
}

function render() {
    count+=1;
    //if (TIME-10 >= startTime){
       //timePass = TIME - startTime;
       //startTime = TIME;
       //var element = document.getElementById("frameRate");
       //element.innerHTML = count / timePass;
       //console.log("Frame rate: " + (count / timePass));
       //count = 0;
    //}
    gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    
    //NEW EYE COORDINATES FOR PERSPECTIVE TRANSFORMATION
    eye = vec3(15*Math.sin(0.5*TIME/3.14159),25,15*Math.cos(0.5*TIME/3.14159));
    //eye = vec3(15, 25, 15);

    eye[1] = eye[1] + 0 ;
   
    // set the projection matrix
    projectionMatrix = ortho(left, right, bottom, ytop, near, far);

    //wold space camera
    //PERSPECTIVE SHIFT
    projectionMatrix = perspective(90, 1, near, far);

    // set the camera matrix
    viewMatrix = lookAt(eye, at , up);
    
    // initialize the modeling matrix stack
    MS= [] ;
    modelMatrix = mat4() ;
    
    // apply the slider rotations
    gRotate(RZ,0,0,1) ;
    gRotate(RY,0,1,0) ;
    gRotate(RX,1,0,0) ;
    
    // send all the matrices to the shaders
    setAllMatrices() ;
    
    // get real time
    var curTime ;
    if( animFlag )
    {
        curTime = (new Date()).getTime() /1000 ;
        if( resetTimerFlag ) {
            prevTime = curTime ;
            resetTimerFlag = false ;
        }
        TIME = TIME + curTime - prevTime ;
        prevTime = curTime ;
    }

    
    //gl.activeTexture(gl.TEXTURE0);
    //gl.bindTexture(gl.TEXTURE_2D, textureArray[0].textureWebGL);
    //gl.uniform1i(gl.getUniformLocation(program, "texture1"), 0);
    
    //gl.activeTexture(gl.TEXTURE1);
    //gl.bindTexture(gl.TEXTURE_2D, textureArray[1].textureWebGL);
    //gl.uniform1i(gl.getUniformLocation(program, "texture2"), 1);
    
    //gl.activeTexture(gl.TEXTURE2);
    //gl.bindTexture(gl.TEXTURE_2D, textureArray[2].textureWebGL);
    //gl.uniform1i(gl.getUniformLocation(program, "texture3"), 2);

    //gl.activeTexture(gl.TEXTURE3);
    //gl.bindTexture(gl.TEXTURE_2D, textureArray[3].textureWebGL);
    //gl.uniform1i(gl.getUniformLocation(program, "texture4”), 3);
    
    //GROUND INCLUDING THE RIVER
    function groundBox(x, y, z, height){
       gPush() ;
       {
          setColor(vec4(0.4,0.4,0.4,1.0)) ;
          gTranslate(x-64.5, y, z) ;
          gScale(60.5,0.25,100) ;
          drawCube() ;
       }
       gPop() ;

       gPush() ;
       {
          setColor(vec4(0,0,0.8,1.0)) ;
          gTranslate(x, y, z) ;
          gScale(4,0.25,100) ;
          drawCube() ;
       }
       gPop() ;

       gPush() ;
       {
          setColor(vec4(0.420,0.557,0.184,1.0)) ;
          gTranslate(x+64.5, y, z) ;
          gScale(60.5,0.25,100) ;
          drawCube() ;
       }
       gPop() ;
    }

    //WASTE FACTORY BUILDING
    function wasteFactory(x,y,z)
    {
       gPush();
       {
          gTranslate(x,y,z);

          //FRONT WALL
          gPush() ;
          {
             setColor(vec4(0.25,0.25,0.25,1.0)) ;
             gScale(0.5,2,8);
             drawCube() ;
          }
          gPop() ;

          //BACK WALL
          gPush() ;
          {
             setColor(vec4(0.25,0.25,0.25,1.0)) ;
             gTranslate(-11,-2,0) ;
             gScale(0.5,4,8);
             drawCube() ;
          }
          gPop() ;

          //LEFT WALL
          gPush() ;
          {
             setColor(vec4(0.25,0.25,0.25,1.0)) ;
             gTranslate(-5.5,-2,7.45) ;
             gScale(5,4,0.5);
             drawCube() ;
          }
          gPop() ;

          //RIGHT WALL
          gPush() ;
          {
             setColor(vec4(0.25,0.25,0.25,1.0)) ;
             gTranslate(-5.5,-2,-7.45) ;
             gScale(5,4,0.5);
             drawCube() ;
          }
          gPop() ;

          //ROOF: LEFT SIDE
          gPush() ;
          {
             setColor(vec4(0.25,0.25,0.25,1.0)) ;
             gTranslate(-5.5,2,7.40) ;
             gRotate(45,0,0,1);
             gScale(4.2426,4.2426,0.5);
             drawCube() ;
          }
          gPop() ;
          
          //ROOF: RIGHT SIDE
          gPush() ;
          {
             setColor(vec4(0.25,0.25,0.25,1.0)) ;
             gTranslate(-5.5,2,-7.40) ;
             gRotate(45,0,0,1);
             gScale(4.2426,4.2426,0.5);
             drawCube() ;
          }
          gPop() ;

          gl.uniform1i( gl.getUniformLocation(program,"useTextures"), 1 );
          gl.activeTexture(gl.TEXTURE0);
          gl.bindTexture(gl.TEXTURE_2D, textureArray[0].textureWebGL);
          gl.uniform1i(gl.getUniformLocation(program, "texture1"), 0);
          //ROOF: FRONT SIDE
          gPush() ;
          {
             setColor(vec4(0.25,0.25,0.25,1.0)) ;
             gTranslate(-2.851,4.647,0) ;
             gRotate(45,0,0,1);
             gScale(0.5,4.2426,8);
             drawCube() ;
          }
          gPop() ;

          //ROOF: BACK SIDE
          gPush() ;
          {
             setColor(vec4(0.25,0.25,0.25,1.0)) ;
             gTranslate(-8.149,4.647,0) ;
             gRotate(-45,0,0,1);
             gScale(0.5,4.2426,8);
             drawCube() ;
          }
          gPop() ;
          gl.uniform1i( gl.getUniformLocation(program,"useTextures"), 0 );
       }
       gPop();
    }

    //SINGLE ROCKET
    function rocket(x, y, z){
       gPush() ;
       {
          
          gTranslate(x,y,z) ;
          
          gPush() ;
          {
             setColor(vec4(0.8,0.0,0.0,1.0)) ;
             gTranslate(0,0,-1.5) ;
             gScale(0.25,0.25,0.25);
             drawSphere() ;
          }
          gPop() ;
    
          gPush() ;
          {
             setColor(vec4(0.420,0.557,0.184,0.0,1.0)) ;
             gTranslate(0,0,0) ;
             gScale(0.5,0.5,3);
             
             drawCylinder() ;
          }
          gPop() ;
    
          gPush() ;
          {
             setColor(vec4(0.8,0.0,0.0,1.0)) ;
             gTranslate(0,0,2) ;
             gScale(0.25,0.25,1);
             drawCone() ;
          }
          gPop() ;
       }
       gPop() ;
    }

    //ALL ROCKETS COMBINED
    function rockets(x, y, z){
       gPush() ;
       {
          gTranslate(x,y,z) ;
          
          gPush();
          {
             setColor(vec4(0.5,0.5,0.5,1.0)) ;
             gTranslate(0,0,0) ;
             gRotate(-90,1,0,0) ;
             gScale(0.8,0.8,1.5);
             drawCone() ;
          }
          gPop() ;

          if (TIME > 14 + 7 && TIME <= 14 + 10.0) {
             gRotate(40*Math.cos(3*((TIME-1.3))/3.14159)-40,0,1,0);
          } else if (TIME > 14+10.0 && TIME <= 14+10.65){
             gRotate(-80,0,1,0);
          } else if (TIME > 14+10.65 && TIME <= 14+11.75){
             gRotate(51.5*Math.cos(3*((TIME+10.49))/3.14159)-51.5,0,1,0);
          } else if (TIME > 14+11.75){
             gRotate(-103,0,1,0);
          }

          gPush() ;
          {
             gTranslate(0,0.4,0.3) ;


             gPush();
             {
                if (TIME > 14+10.0 && TIME <= 14+10.65){
                   gTranslate(0,0,11*Math.cos((10.0*TIME-10)/3.14159)+11);
                } else if (TIME > 14+10.65){
                   gTranslate(0,-5,0);
                }
                rocket(-1.0, 0.5, 0);
                rocket(-0.5, 0.5, 0);
                rocket(0, 0.5, 0);
                rocket(0.5, 0.5, 0);
                rocket(1.0, 0.5, 0);
             }
             gPop();
             
             gPush();
             {
                if (TIME > 14+11.5 && TIME <= 14+12.20){
                   gTranslate(0,0,12*Math.cos((10*TIME-25)/3.14159)+12);
                } else if (TIME > 14+12.20) {
                   gTranslate(0,-5,0);
                }
                rocket(-1.0, 0, 0);
                rocket(-0.5, 0, 0);
                rocket(0, 0, 0);
                rocket(0.5, 0, 0);
                rocket(1, 0, 0);
             }
             gPop();
          }
          gPop();
       }
       gPop() ;
    }
    
    //LIGHT FOR THE TRUCK
    function headLight(x,y,z){
       gPush();
       {
          setColor(vec4(1.0,1.0,1.0,1.0)) ;
          gTranslate(x,y,z) ;
          gScale(0.15,0.15,0.001);
          drawSphere() ;
       }
       gPop();
    }

    //SINGLE GRILL LINE FOR THE TRUCK
    function grillLine(x,y,z){
       gPush() ;
       {
          setColor(vec4(0.0,0.0,0.0,1.0)) ;
          gTranslate(x,y,z) ;
          gScale(0.7,0.02,0.001);
          drawCube() ;
       }
       gPop();
    }

    //CABIN FOR THE TRUCK
    function cabin (x,y,z){
       gPush() ;
       {
          //CABIN (3 PARTS)
          gTranslate(x,y,z);
          gPush() ;
          {
             setColor(vec4(0.420,0.557,0.184,0.0,1.0)) ;
             //gTranslate(0, 0.25,-0.10) ;
             gScale(1.25,0.75,0.6);
             drawCube() ;
          }
          gPop() ;

          gPush() ;
          {
             setColor(vec4(0.420,0.557,0.184,0.0,1.0)) ;
             gTranslate(0, -0.75, 0.75) ;
             gScale(1.25,0.5,0.35);
             drawCube() ;
          }
          gPop() ;

          gPush() ;
          {
             setColor(vec4(0.420,0.557,0.184,0.0,1.0)) ;
             gTranslate(0, 0.1380, 0.6263) ;
             gRotate(-26.57,1,0,0);
             gScale(1.25,0.559,0.25);
             drawCube() ;
          }
          gPop() ;


	   //WINDSHIELD
          gPush() ;
          {
             setColor(vec4(0.5,0.5,0.5,1.0)) ;

             gTranslate(0, 0.27, 0.84) ;
             gRotate(-26.57,1,0,0);
             
             gScale(1.15,0.43,0.015);
             drawCube() ;
          }
          gPop() ;


          //SIDE WINDOWS
          gPush() ;
          {
             setColor(vec4(0.5,0.5,0.5,1.0)) ;             
             gTranslate(1.25, 0.1, 0) ;
             gRotate(90,0,1,0);
             gScale(0.4,0.4,0.015);
             drawCube() ;
          }
          gPop() ;

          gPush() ;
          {
             setColor(vec4(0.5,0.5,0.5,1.0)) ;             
             gTranslate(-1.25, 0.1, 0) ;
             gRotate(90,0,1,0);
             gScale(0.4,0.4,0.015);
             drawCube() ;
          }
          gPop() ;

          //HEADLIGHTS
          headLight(-1.0,-1,1.1);
          headLight(1.0,-1,1.1);

          //GRILL
          grillLine(0,-0.87,1.1);
          grillLine(0,-1.0,1.1);
          grillLine(0,-1.12,1.1);
       }
       gPop() ;
    }

    //PLATROFM FOR TRUCK   
    function platform(x,y,z){
       gPush();
       {
          gTranslate(x,y,z);
          gPush() ;
          {
             setColor(vec4(0.0,0.0,0.0,1.0)) ;
             gScale(0.8,0.4,3.0);
             drawCube() ;
          }
          gPop() ;

          gPush() ;
          {
             setColor(vec4(0.0,0.0,0.0,1.0)) ;
             //gTranslate(0.000,0.159,3.059) ;
             gTranslate(0.000,0.21,3.153) ;
             gRotate(66.8014,1,0,0) ;
             gScale(0.798,0.38078,0.5);
             drawCube() ;
          }
          gPop() ;
       }
       gPop();

    }

    //SINGLE WHEEL FOR TRUCK
    function wheel(x,y,z){
       gPush();
       {
          gTranslate(x,y,z);
          gRotate(90, 0,1,0) ;
          gPush() ;
          {
             setColor(vec4(0.5,0.5,0.5,1.0)) ;
             gScale(1.5,1.5,0.5);
             drawCylinder() ;
          }
          gPop() ;

          gPush() ;
          {
             setColor(vec4(0.5,0.5,0.5,1.0)) ;
             gTranslate(0,0,0.25) ;
             gScale(0.75,0.75,0.01);
             drawSphere() ;
          }
          gPop() ;

          gPush() ;
          {
             setColor(vec4(0.5,0.5,0.5,1.0)) ;
             gTranslate(0,0,-0.25) ;
             gScale(0.75,0.75,0.01);
             drawSphere() ;
          }
          gPop() ;

          gPush() ;
          {
             gTranslate(0,0,0.26) ;
             setColor(vec4(0.2,0.2,0.2,1.0)) ;
             gScale(0.45,0.45,0.01);
             drawSphere() ;
          }
          gPop() ;

          gPush() ;
          {
             gTranslate(0,0,-0.26) ;
             setColor(vec4(0.2,0.2,0.2,1.0)) ;
             gScale(0.45,0.45,0.01);
             drawSphere() ;
          }
          gPop() ;
       }
       gPop() ;
    }

    //RADIOACTIVE WASTE IN A FORM OF A SPHERE
    function waste(x,y,z)
    {
       gPush() ;
       {
             gTranslate(x,y,z) ;
             setColor(vec4(0.93,1,0,1.0)) ;
             gScale(0.4,0.4,0.4);
             drawSphere() ;
       }
       gPop();
    }

    //TRUNK FOR TRUCKS ON LEFT SIDE
    function trunk(x,y,z, timeShift) {
       gPush();
       {
          gTranslate(x,y,z) ;
          //gRotate(-45,1,0,0);
          if ((TIME + timeShift) % 20.5 > 6.5 && (TIME + timeShift) % 20.5 <= 13){
             gRotate(45*Math.cos(3*((TIME+timeShift)%20.5)/3.14159)-45,1,0,0) ;
          }
          gPush() ;
          {
             setColor(vec4(0.420,0.557,0.184,0.0,1.0)) ;
             gTranslate(0.000,0,2.23) ;
             gScale(1.25,0.05,2.25);
             drawCube() ;
          }
          gPop() ;

          gPush() ;
          {
             setColor(vec4(0.420,0.557,0.184,0.0,1.0)) ;
             gTranslate(1.2,0.45,2.23) ;
             gScale(0.05,0.5,2.25);
             drawCube() ;
          }
          gPop() ;

          gPush() ;
          {
             setColor(vec4(0.420,0.557,0.184,0.0,1.0)) ;
             gTranslate(-1.2,0.45,2.23) ;
             gScale(0.05,0.5,2.25);
             drawCube() ;
          }
          gPop() ;

          gPush() ;
          {
             setColor(vec4(0.420,0.557,0.184,0.0,1.0)) ;
             gTranslate(0,0.45,4.43) ;
             gScale(1.25,0.5,0.05);
             drawCube() ;
          }
          gPop() ;

          if ((TIME + timeShift) % 20.5 > 7.5 && (TIME + timeShift) % 20.5 <= 11.5){
             gTranslate(0,0,3*Math.sin(3*((TIME + timeShift) % 20.5 + 1)/3.14159) - 3);
          } else if ((TIME + timeShift) % 20.5 > 11.5 && (TIME + timeShift) % 20.5 <= 20.5) {
             gTranslate(0,-7,0);
          }

          waste(-0.75,0.5,0.5);
          waste(0,0.5,0.5);
          waste(0.75,0.5,0.5);

          waste(-0.75,0.5,1.3);
          waste(0,0.5,1.3);
          waste(0.75,0.5,1.3);

       }
       gPop();
    }


    //TRUCK
    function truck(x, y, z, timeShift, rocketsON)
    {
       gPush() ;
       {
          gTranslate(x,y,z) ;

          if (rocketsON == 1){
             rockets(0,0,-4.25);
          } else {
             gRotate(-90,0,1,0);
             trunk(0.000,-0.45,-5.7, timeShift);
          }

          cabin(0, 0.25,-0.1);
          platform(0,-0.9,-2.7);

          //WHEELS
          wheel(1.05,-1.4,-0.5);
          wheel(-1.05,-1.4,-0.5);

          wheel(1.05,-1.4,-3.4);
          wheel(-1.05,-1.4,-3.4);

          wheel(1.05,-1.4,-5);
          wheel(-1.05,-1.4,-5);
       }
       gPop() ;
    }

    gTranslate(0,-3,0);
    
    //MOVING ALGORITHM FOR TRUCKS WITH TRUNKS
    function truckPathLeft(x,y,z,timeShift, rocketsON)
    {
       gPush() ;
       {
          if ((TIME + timeShift) % 20.5 <= 6.5 )  {
             truck(10*Math.sin(1.5*((TIME + timeShift) % 20.5 - 3.25)/3.14159) + x,y,z, timeShift, rocketsON);
          } else if ((TIME + timeShift)% 20.5 > 6.5 && (TIME + timeShift)% 20.5 <= 14) {
             truck(x + 10,y,z, timeShift, rocketsON);
          } else if ((TIME + timeShift)% 20.5 >= 14 && (TIME + timeShift) % 20.5 < 20.5) {
             truck(10*Math.sin(1.5*((TIME + timeShift) % 20.5 + 2.50)/3.14159) + x,y,z, timeShift, rocketsON);
          }
       }
       gPop();
    }

    //MOVING ALGORITHM FOR TRUCK WITH ROCKETS
    function truckPathRight(x,y,z,timeShift, rocketsON)
    {
       gPush() ;
       {
          if (TIME >= 14 && TIME <= 14+6.5)  {
             truck(x, y, 20*Math.sin(1.5*((TIME + timeShift) - 3.25)/3.14159) - z, timeShift, rocketsON);
          } else if (TIME > 14 + 6.5 && TIME < 14 + 12.20) {
             truck(x,y,z-10.0, timeShift, rocketsON);
          } else if (TIME > 14 + 12.20 && TIME <= 31) {
             truck(x, y, 20*Math.sin(1.5*((TIME + timeShift) - 22.0)/3.14159) - z, timeShift, rocketsON);
          }
       }
       gPop();
    }
    
    //EXPLOSION OF TRUCK AFTER LAUNH OF ROCKETS
    function explosion(x,y,z, timeShift)
    {
        gPush() ;
        {
            gTranslate(x,y,z);
            setColor(vec4(1,0.85,0,1.0)) ;
            gScale(3*Math.cos((30*TIME+timeShift)/3.14159) + 4,3*Math.cos((30*TIME+timeShift)/3.14159) + 4,3*Math.cos((30*TIME+timeShift)/3.14159) + 4);
            drawSphere() ;
        }
        gPop();
    }


    //RUN ALL METHODS ABOVE
    groundBox(0,0,0,0.25);
    wasteFactory(-22.5,6.0,0);
    
//    if (TIME < 24.65){
//       truckPathLeft(-20,2.4,5,3.5,0);
//    }
//    if (TIME < 26.20){
//       truckPathLeft(-20,2.4,-5,0,0);
//    }
//    //truck(15,2.4,5,0,1);
//    truckPathRight(15, 2.4, 15, -14, 1);
    

    if (TIME <= 24.7){
        truckPathLeft(-20,2.4,5,3.5,0);
    }
    if (TIME > 24.70 && TIME <= 25.20){
        explosion(-7,0.4,5, 0.0);
    }
    
    if (TIME <= 26.45){
        truckPathLeft(-20,2.4,-5,0,0);
    }
    if (TIME > 26.35 && TIME <= 26.85){
        explosion(-7,0.4,-6, 12);
    }
    truckPathRight(15, 2.4, 15, -14, 1);
    
    

   
    if( animFlag )
        window.requestAnimFrame(render);
}

// A simple camera controller which uses an HTML element as the event
// source for constructing a view matrix. Assign an "onchange"
// function to the controller as follows to receive the updated X and
// Y angles for the camera:
//
//   var controller = new CameraController(canvas);
//   controller.onchange = function(xRot, yRot) { ... };
//
// The view matrix is computed elsewhere.
function CameraController(element) {
    var controller = this;
    this.onchange = null;
    this.xRot = 0;
    this.yRot = 0;
    this.scaleFactor = 3.0;
    this.dragging = false;
    this.curX = 0;
    this.curY = 0;
    
    // Assign a mouse down handler to the HTML element.
    element.onmousedown = function(ev) {
        controller.dragging = true;
        controller.curX = ev.clientX;
        controller.curY = ev.clientY;
    };
    
    // Assign a mouse up handler to the HTML element.
    element.onmouseup = function(ev) {
        controller.dragging = false;
    };
    
    // Assign a mouse move handler to the HTML element.
    element.onmousemove = function(ev) {
        if (controller.dragging) {
            // Determine how far we have moved since the last mouse move
            // event.
            var curX = ev.clientX;
            var curY = ev.clientY;
            var deltaX = (controller.curX - curX) / controller.scaleFactor;
            var deltaY = (controller.curY - curY) / controller.scaleFactor;
            controller.curX = curX;
            controller.curY = curY;
            // Update the X and Y rotation angles based on the mouse motion.
            controller.yRot = (controller.yRot + deltaX) % 360;
            controller.xRot = (controller.xRot + deltaY);
            // Clamp the X rotation to prevent the camera from going upside
            // down.
            if (controller.xRot < -90) {
                controller.xRot = -90;
            } else if (controller.xRot > 90) {
                controller.xRot = 90;
            }
            // Send the onchange event to any listener.
            if (controller.onchange != null) {
                controller.onchange(controller.xRot, controller.yRot);
            }
        }
    };
}
