

var canvas;
var gl;

var program ;

var near = -100;
var far = 100;


var left = -6.0;
var right = 6.0;
var ytop =6.0;
var bottom = -6.0;


var lightPosition2 = vec4(100.0, 100.0, 100.0, 1.0 );
var lightPosition = vec4(0.0, 0.0, 100.0, 1.0 );

var lightAmbient = vec4(0.2, 0.2, 0.2, 1.0 );
var lightDiffuse = vec4( 1.0, 1.0, 1.0, 1.0 );
var lightSpecular = vec4( 1.0, 1.0, 1.0, 1.0 );

var materialAmbient = vec4( 1.0, 0.0, 1.0, 1.0 );
var materialDiffuse = vec4( 1.0, 0.8, 0.0, 1.0 );
var materialSpecular = vec4( 0.4, 0.4, 0.4, 1.0 );
var materialShininess = 10000.0;

var ambientColor, diffuseColor, specularColor;

var modelMatrix, viewMatrix, modelViewMatrix, projectionMatrix, normalMatrix;
var modelViewMatrixLoc, projectionMatrixLoc, normalMatrixLoc;
var eye;
var at = vec3(0.0, 0.0, 0.0);
var up = vec3(0.0, 1.0, 0.0);

var RX = 0 ;
var RY = 0 ;
var RZ = 0 ;

var MS = [] ; // The modeling matrix stack
var TIME = 0.0 ; // Realtime
var prevTime = 0.0 ;
var resetTimerFlag = true ;
var animFlag = false ;

function setColor(c)
{
    ambientProduct = mult(lightAmbient, c);
    diffuseProduct = mult(lightDiffuse, c);
    specularProduct = mult(lightSpecular, materialSpecular);
    
    gl.uniform4fv( gl.getUniformLocation(program,
                                         "ambientProduct"),flatten(ambientProduct) );
    gl.uniform4fv( gl.getUniformLocation(program,
                                         "diffuseProduct"),flatten(diffuseProduct) );
    gl.uniform4fv( gl.getUniformLocation(program,
                                         "specularProduct"),flatten(specularProduct) );
    gl.uniform4fv( gl.getUniformLocation(program,
                                         "lightPosition"),flatten(lightPosition) );
    gl.uniform1f( gl.getUniformLocation(program, 
                                        "shininess"),materialShininess );
}

window.onload = function init() {

    canvas = document.getElementById( "gl-canvas" );
    
    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { alert( "WebGL isn't available" ); }

    gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 0.2, 0.2, 1.0, 1.0 );
    
    gl.enable(gl.DEPTH_TEST);

    //
    //  Load shaders and initialize attribute buffers
    //
    program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram( program );
    

    setColor(materialDiffuse) ;

    Cube.init(program);
    Cylinder.init(9,program);
    Cone.init(36,program) ;
    Sphere.init(36,program) ;

    
    modelViewMatrixLoc = gl.getUniformLocation( program, "modelViewMatrix" );
    normalMatrixLoc = gl.getUniformLocation( program, "normalMatrix" );
    projectionMatrixLoc = gl.getUniformLocation( program, "projectionMatrix" );
    
    
    gl.uniform4fv( gl.getUniformLocation(program, 
       "ambientProduct"),flatten(ambientProduct) );
    gl.uniform4fv( gl.getUniformLocation(program, 
       "diffuseProduct"),flatten(diffuseProduct) );
    gl.uniform4fv( gl.getUniformLocation(program, 
       "specularProduct"),flatten(specularProduct) );	
    gl.uniform4fv( gl.getUniformLocation(program, 
       "lightPosition"),flatten(lightPosition) );
    gl.uniform1f( gl.getUniformLocation(program, 
       "shininess"),materialShininess );

    
    document.getElementById("sliderXi").onchange = function() {
        RX = this.value ;
        window.requestAnimFrame(render);
    };
    document.getElementById("sliderYi").onchange = function() {
        RY = this.value;
        window.requestAnimFrame(render);
    };
    document.getElementById("sliderZi").onchange = function() {
        RZ =  this.value;
        window.requestAnimFrame(render);
    };

    document.getElementById("animToggleButton").onclick = function() {
        if( animFlag ) {
            animFlag = false;
        }
        else {
            animFlag = true  ;
            resetTimerFlag = true ;
            window.requestAnimFrame(render);
        }
        console.log(animFlag) ;
    };

    
    render();
}

// Sets the modelview and normal matrix in the shaders
function setMV() {
    modelViewMatrix = mult(viewMatrix,modelMatrix) ;
    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix) );
    normalMatrix = inverseTranspose(modelViewMatrix) ;
    gl.uniformMatrix4fv(normalMatrixLoc, false, flatten(normalMatrix) );
}

// Sets the projection, modelview and normal matrix in the shaders
function setAllMatrices() {
    gl.uniformMatrix4fv(projectionMatrixLoc, false, flatten(projectionMatrix) );
    setMV() ;
    
}

// Draws a 2x2x2 cube center at the origin
// Sets the modelview matrix and the normal matrix of the global program
function drawCube() {
    setMV() ;
    Cube.draw() ;
}

// Draws a sphere centered at the origin of radius 1.0.
// Sets the modelview matrix and the normal matrix of the global program
function drawSphere() {
    setMV() ;
    Sphere.draw() ;
}
// Draws a cylinder along z of height 1 centered at the origin
// and radius 0.5.
// Sets the modelview matrix and the normal matrix of the global program
function drawCylinder() {
    setMV() ;
    Cylinder.draw() ;
}

// Draws a cone along z of height 1 centered at the origin
// and base radius 1.0.
// Sets the modelview matrix and the normal matrix of the global program
function drawCone() {
    setMV() ;
    Cone.draw() ;
}

// Post multiples the modelview matrix with a translation matrix
// and replaces the modeling matrix with the result
function gTranslate(x,y,z) {
    modelMatrix = mult(modelMatrix,translate([x,y,z])) ;
}

// Post multiples the modelview matrix with a rotation matrix
// and replaces the modeling matrix with the result
function gRotate(theta,x,y,z) {
    modelMatrix = mult(modelMatrix,rotate(theta,[x,y,z])) ;
}

// Post multiples the modelview matrix with a scaling matrix
// and replaces the modeling matrix with the result
function gScale(sx,sy,sz) {
    modelMatrix = mult(modelMatrix,scale(sx,sy,sz)) ;
}

// Pops MS and stores the result as the current modelMatrix
function gPop() {
    modelMatrix = MS.pop() ;
}

// pushes the current modelViewMatrix in the stack MS
function gPush() {
    MS.push(modelMatrix) ;
}



function render() {
    
    gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    
    eye = vec3(0,0,10);
    MS = [] ; // Initialize modeling matrix stack
    
    modelMatrix = mat4() ;
    
    // set the camera matrix
    viewMatrix = lookAt(eye, at , up);
   
    // set the projection matrix
    projectionMatrix = ortho(left, right, bottom, ytop, near, far);
    
    
    gRotate(RZ,0,0,1) ;
    gRotate(RY,0,1,0) ;
    gRotate(RX,1,0,0) ;
    
    
    
    setAllMatrices() ;
    
    var curTime ;
    if( animFlag )
    {
        curTime = (new Date()).getTime() /1000 ;
        if( resetTimerFlag ) {
            prevTime = curTime ;
            resetTimerFlag = false ;
        }
        TIME = TIME + curTime - prevTime ;
        prevTime = curTime ;
    }



    //START OF FUNCTION IMPLEMENTATIONS


    //USE X,Y,Z TO CHANGE THE POSITION OF THE GROUND BOX
    //THE GROUND BOX IS A SQUARE SHAPE (sideLength IS THE SAME WHEN SCALING IN THE X AND Z DIRECTIONS)
    //THE height VARIABLE SCALES THE GROUND BOX IN THE Y DIRECTION
    function groundBox(x, y, z, sideLength, height){
       gPush() ;
       {
          setColor(vec4(0.420,0.557,0.184,1.0)) ;
          gScale(sideLength,height,sideLength) ;
          gTranslate(x, y, z) ;
          drawCube() ;
       }
       gPop() ;
    }

    //USE X,Y,Z TO CHANGE THE POSITION OF THE ROCK
    //THE size VARIABLE IS USED TO SCALE THE SPHERE IN ALL 3 DIRECTIONS
    function rock(x, y, z, size){
       gPush() ;
       {
          setColor(vec4(0.412,0.412,0.412,1.0)) ;
          gTranslate(x,y,z) ;
          gScale(size,size,size) ;
          drawSphere() ;
       }
       gPop();
    }


    //A STRAND OF SEAWEED IS A CHAIN OF 10 SPHERES
    //POSITION THE SEAWEED USING X,Y,Z COORDINATES
    //THE BOTTOM SPHERE DOES NOT ROTATE
    //THE TOP 9 SPHERES ROTATE AROUND THE Z-AXIS
    //INSIDE THE LOOP, EACH SEPARATE AXIS OF ROTATION IS MOVED UP BY 0.5 AND
    // EACH SEPARATE SPHERE IS MOVED UP BY 0.25

    //THE FORMULA FOR ROTATION IS A*SIN(B*I + C*TIME) + D*COS(E*I + F*TIME)
    //A AND D MANIPULATE THE AMPLITUDE AND ANGLE OF THE STRAND
    //B and E MANIPULATE THE SHAPE OF THE STRAND
    //C MANIPULATES THE SPEED OF ROTATION (THE POSITIVE/NEGATIVE SIGN OF C DETERMINES
    //   THE WAVE DIRECTION OF THE STRAND)
    //F MANIPULATES THE FREQUENCY OF THE WAVE IN THE STRAND

    function seaweed(x,y,z) {
       gPush() ;
       {
          setColor(vec4(0.0,0.7,0.0,1.0)) ;
          gTranslate(x,y-0.25,z) ;

          //THE FIRST RUN OF THE FOR-LOOP IS THE BOTTOM SPHERE WHICH DOES NOT ROTATE
          for (i = 0; i < 10; i++){
             if (i > 0){
                 
                 gTranslate(0.0,0.5,0.0) ;
                 gRotate(20*Math.sin(14*i-3*TIME/3.14159)+1*Math.cos(14*i+3*TIME/3.14159),0,0,1) ;
             }
             gPush() 
             {
                gTranslate(0, 0.25,0) ;
                gScale(0.1,0.25,0.1) ;
                drawSphere() ;
             }
             gPop() ;
          }
       }
       gPop() ;
    }

    //POSITION THE ENVIRONMENT USING X,Y,Z COORDINATES
    //THE ENVIRONMENT INCLUDES 2 ROCKS AND SEAWEED
    //THE LOCATION OF THE SMALL ROCK AND SEAWEED IS SET WITH RESPECT TO THE
    //  COORDINATE SYSTEM OF THE LARGE ROCK
    function environment(x, y, z){
       gPush();
       {
          gTranslate(x,y,z);

          //SET THE LOCATION AND SIZE OF THE 2 SEPARATE ROCKS
       
          //LARGE ROCK
          rock(0,0,0,  0.5);

          //SMALL ROCK
          rock(-0.777,-0.2,0.0,  0.3)

          //SET THE LOCATION OF THE 3 SEPARATE STRANDS OF SEAWEED
          seaweed(-0.5, 0.25, 0);
          seaweed(0, 0.75, 0);
          seaweed(0.5, 0.25, 0);
       }
       gPop() ;
    }

    //FISH PUPIL IS A BLACK SPHERE
    //POSITION THE PUPIL USING X,Y,Z COORDINATES
    function fishPupil (x, y, z){
       gPush() ;
       {
          setColor(vec4(0.0,0.0,0.0,1.0)) ;
          gTranslate(x,y,z)
          gScale(0.055,0.055,0.055) ;
          drawSphere() ;
       }
       gPop() ;
    }

    //FISH EYE IS MADE UP OF A WHITE SPHERE AND A PUPIL
    //POSITION THE EYE USING X,Y,Z COORDINATES
    //THE PUPIL IS POSITIONED WITH RESPECT TO THE EYE
    //THE PUPIL IS POSITIONED PARTIALLY INSIDE THE EYE ALONG THE Z-AXIS
    function fishEye(x, y, z){
       gPush() ;
       {
          gTranslate(x,y,z);
          gPush() ;
          {
             setColor(vec4(1.0,1.0,1.0,1.0)) ;
             gScale(0.1,0.1,0.1) ;
             drawSphere() ;
          }
          gPop() ;
          fishPupil(0,0,0.07);
       }
       gPop() ;
    }
 
    //THE BODY OF THE FISH IS MADE OF 2 CONES 
    //THE LARGER CONE IS INVERTED IN THE Z DIRECTION
    //POSITION THE 2 CONES TOGETHER USING X,Y,Z COORDINATES
    //THE POSITION OF THE LARGER CONE IS SET WITH RESPECT TO THE COORDINATE SYSTEM OF THE SMALLER CONE
    function fishBody(x,y,z){
       gPush() ;
       {
          gTranslate(x,y,z) ;

          //SMALL(FRONT) CONE
          gPush() ;
          {
             setColor(vec4(0.6,0.6,0.6,1.0)) ;
             gScale(0.5,0.5,0.5) ;
             drawCone() ;
          }
          gPop() ;

          //LARGE(BACK) CONE
          gPush() ;
          {
             setColor(vec4(1.0,0.2,0.2,1.0)) ;
             gScale(0.5,0.5,-2.0) ;
             gTranslate(0,0,0.625) ;
             drawCone() ;
          }
          gPop() ;
       }
       gPop() ;
    }

    //TRANSLATE THE TAIL AND FINS TOGETHER USING X,Y,Z COORDINATES
    //THE POSITION OF THE LARGER FIN(CONE) AND THE SMALLER FIN IS SET WITH RESPECT TO THE
    //   COORDINATE SYSTEM OF THE TAIL (WHITE SPHERE)
    //ROTATE THE FINS AROUND THE Y-AXIS (USE MULTIPLIER 50 TO INCREASE AMPLITUDE, USE 30 FOR SPEED)
    //EACH FIN IS ROTATED ONCE BY 45 DEGRES IN OPPOSITE DIRECTIONS AROUND THE X-AXIS
    //EACH FIN IS MOVED TO THE BACK OF THE TAIL BY 0.5 ALONG THE Z-AXIS
    function tailFins(x, y, z)
    {
       gPush();
       {
          //TAIL (WHITE SPHERE)
          gTranslate(x,y,z);
          gPush() ;
          {
             setColor(vec4(1.0,1.0,1.0,1.0)) ;
             gScale(0.15,0.15,0.15) ;
             drawSphere() ;
          }
          gPop() ;


          //SMALL FIN
          gRotate(50*Math.sin(30*TIME/3.14159),0,1,0);
          gPush() ;
          {
             setColor(vec4(1.0,0.2,0.2,1.0)) ;
             gRotate(-45,1,0,0) ;
             gScale(0.2,0.2,-0.5) ;
             gTranslate(0.0,0.0,0.5) ;
             drawCone() ;
          }
          gPop() ;

          //LARGE FIN
          gPush() ;
          {
             setColor(vec4(1.0,0.2,0.2,1.0)) ;
             gRotate(45,1,0,0) ;
             gScale(0.2,0.2,-1) ;
             gTranslate(0.0,0.0,0.5);        
             drawCone() ;
          }
          gPop() ;
       }
       gPop();
    }

    //ROTATE ALL PARTS OF THE FISH WITH RESPECT TO THE COORDINATE SYSTEM OF THE WHOLE FISH
    //    (ROTATES CLOCKWISE AROUND THE Y-AXIS)
    //USE THE COSINE FUNCTION TO MOVE THE FISH UP AND DOWN AND USE X,Y,Z FOR POSITIONING
    //DRAW EACH SEPARATE EYE OF THE FISH
    //DRAW THE BODY OF THE FISH AT LOCATION ZERO WITH RESPECT TO THE COORDINATE SYSTEM OF THE WHOLE FISH
    //DRAW THE TAIL AND FINS AT THE BACK OF THE FISH (MOVE ALONG Z-AXIS)
    function fish(x, y, z){
       gPush() ;
       {
          gRotate(-TIME*90/3.14159,0,1,0) ;
          gTranslate(x, 0.8*Math.cos(TIME) + y, z) ;

          fishEye(-0.25,0.25,0);
          fishEye(0.25,0.25,0);

          fishBody(0,0,0);

          tailFins(0,0,-2.37);
       }
       gPop() ;
    }

    //END OF FUNCTION IMPLEMENTATIONS






    //START CALLING THE FUNCTIONS HERE

    //SHIFT DOWN THE ENTIRE SCENE ALONG THE Y-AXIS
    gTranslate(0,-2,0) ;
   
    //SET LOCATION (STAYS AT ZERO), SIDE LENGTH AND HEIGHT OF THE GROUND BOX 
    //TO FIT INTO THE SCREEN (SCREEN SIZE IS 6)
    groundBox(0,0,0,  6,  0.25);
    
    //SET THE LOCATION OF THE ENVIRONMENT (ROCKS AND SEAWEED)
    //THE LOCATION IS DETERMINED BY THE LARGE ROCK
    environment(0.0, 0.75, 0.0)

    //SET THE LOCATION OF THE FISH
    fish(2.25,1.75,0.25);      
    

    //END OF FUNCTION CALLING





    if( animFlag )
        window.requestAnimFrame(render);
}