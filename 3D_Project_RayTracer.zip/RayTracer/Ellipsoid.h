//#pragma once

#include "Vector.h"
#include "Ray.h"
#include <iostream>
using namespace std;

#define MIN_DIST 0.0001 //min distance
//Store information for surface reflect coefficient of Ellipsoid class
struct Coefficient {
	double Ka; //surface reflect coefficient for ambient
	double Kd; //surface reflect coefficient for diffuse
	double Ks; //surface reflect coefficient for specular
	double Kr; //surface reflect coefficient for reflection rays of other object
	double n; //shininess of the object

	Coefficient();
	Coefficient(double Ka, double Kd, double Ks, double Kr, double n);
};

Coefficient::Coefficient() {
	this->Ka = 0;
	this->Kd = 0;
	this->Ks = 0;
	this->Kr = 0;
	this->n = 0;
}

Coefficient::Coefficient(double Ka, double Kd, double Ks, double Kr, double n) {
	this->Ka = Ka;
	this->Kd = Kd;
	this->Ks = Ks;
	this->Kr = Kr;
	this->n = n;
}

//hold the information for intersection
struct PtIntsect {
	double time;
	double inside;
	Point intsPt;
	PtIntsect() {}
	PtIntsect(double time, double inside, const Point& intsPt) {
		this->time = time;
		this->inside = inside;
		this->intsPt = intsPt;
	}
	//only if no intersect point happens
	PtIntsect(double time, double inside) {
		this->time = time;
		this->inside = inside;
	}
	~PtIntsect() {}
};

class Ellipsoid
{
public:
	Point centre;
	Dimension radius; //scaling factor for radius of this sphere
	Color color;
	Coefficient attribute;
	bool isHollow; //if the sphere have hole (it is hollow sphere)
	Dimension invPPart; //positive direction ([point and center distance] exceed this will be invalid)
	Dimension invNPart; //negative direction (negative of [point and center distance] exceed this will be invalid)

	Ellipsoid();
	Ellipsoid(const Dimension & radius, const Point & centre, const Color & color, const Coefficient & attb); //C++ won't work for 4 attribute
	Ellipsoid(double a, double b, double c, const Point& centre, const Color& color, const Coefficient& attb); //C++ won't work for this constructor
	~Ellipsoid();

	//return the time and whether inside the sphere if ray intersect
	PtIntsect intersect(Ray& ray);


	bool isShadow(Ray& vec, double maxTime);
	//return intersect point of ray and this Ellipsoid, if no intersection return null pointer
	//Point intersectPt(Ray& ray);
	Color getAmbient(Color ambColor);
	Color getDeffuse(Color lightColor, Vector normal, Vector lightDir);
	Color getSpecular(Color lightColor, Vector reflect, Vector rayDir);

	void setHolPX(double value);
	void setHolPY(double value);
	void setHolPZ(double value);
	void setHolNX(double value);
	void setHolNY(double value);
	void setHolNZ(double value);

	bool validPoint(const Point& point);

	Vector normal(double x, double y, double z, bool inside);
	Vector normal(Point& pt, bool inside);
};

//generate an sphere with radius of 1 and located at origin, with color of white
Ellipsoid::Ellipsoid() {
	this->radius = Dimension(1, 1, 1);
	this->centre = Point(0, 0, 0);
	this->color = Color(1, 1, 1);
	this->attribute = Coefficient();
	this->isHollow = false;
	this->invPPart = Dimension(1.0 + MIN_DIST, 1.0 + MIN_DIST, 1.0 + MIN_DIST);
	this->invNPart = Dimension(-1.0 - MIN_DIST, -1.0 - MIN_DIST, -1.0 - MIN_DIST);
}

//generate an sphere with radius of radius and located at centre, with color of color
Ellipsoid::Ellipsoid(const Dimension& radius, const Point& centre, const Color& color, const Coefficient& coff) {
	this->centre = centre;
	this->radius = radius;
	this->color = color;
	this->attribute = coff;
	this->isHollow = false;
	this->invPPart = Dimension(1.0 + MIN_DIST, 1.0 + MIN_DIST, 1.0 + MIN_DIST);
	this->invNPart = Dimension(-1.0 - MIN_DIST, -1.0 - MIN_DIST, -1.0 - MIN_DIST);
}

Ellipsoid::Ellipsoid(double a, double b, double c, const Point& centre, const Color& color, const Coefficient& coff) {
	this->centre = centre;
	this->radius = Dimension(a, b, c);
	this->color = color;
	this->attribute = coff;
	this->isHollow = false;
	this->invPPart = Dimension(1.0 + MIN_DIST, 1.0 + MIN_DIST, 1.0 + MIN_DIST);
	this->invNPart = Dimension(-1.0 - MIN_DIST, -1.0 - MIN_DIST, -1.0 - MIN_DIST);
}

Ellipsoid::~Ellipsoid()
{
}

//set hollow boundrary (normalized to [-1, 1]) compare to radius of sphere
void Ellipsoid::setHolPX(double value) {
	double dif = value - (this->centre.x + this->radius.x);
	if (dif < 0) {
		this->isHollow = true;
		invPPart.x = (value - this->centre.x) / this->radius.x;
	}
}
void Ellipsoid::setHolPY(double value) {
	double dif = value - (this->centre.y + this->radius.y);
	if (dif < 0) {
		this->isHollow = true;
		invPPart.y = (value - this->centre.y) / this->radius.y;
	}
}
void Ellipsoid::setHolPZ(double value) {
	double dif = value - (this->centre.z + this->radius.z);
	if (dif < 0) {
		this->isHollow = true;
		invPPart.z = (value - this->centre.z) / this->radius.z;
	}
}
void Ellipsoid::setHolNX(double value) {
	double dif = value - (this->centre.x - this->radius.x);
	if (dif > 0) {
		this->isHollow = true;
		invPPart.x = (value - this->centre.x) / this->radius.x;
	}
}
void Ellipsoid::setHolNY(double value) {
	double dif = value - (this->centre.y - this->radius.y);
	if (dif > 0) {
		this->isHollow = true;
		invPPart.y = (value - this->centre.y) / this->radius.y;
	}
}
void Ellipsoid::setHolNZ(double value) {
	double dif = value - (this->centre.z - this->radius.z);
	if (dif > 0) {
		this->isHollow = true;
		invPPart.z = (value - this->centre.z) / this->radius.z;
	}
}

//return time when intersect happens, if no intersect point, time returned is -1
PtIntsect Ellipsoid::intersect(Ray& ray) {
	Vector rayDirScaled = ray.direction / this->radius; //first scale the direction
	Point rayOrgMoved = ray.origin - this->centre; //transform to Ellipsoid cooridnate system
	rayOrgMoved /= this->radius; //scaling to fit change of Ellipsoid to Sphere

	double a = rayDirScaled.lenSqr(); //get the square of length of ray
	double b = 2 * rayDirScaled.dot(rayOrgMoved);
	double c = rayOrgMoved.lenSqr() - 1;

	double discriminant = b * b - 4 * a*c;
	//if no intersect point
	if (discriminant < 0) {
		return PtIntsect(-1, false);
	}
	//get root of ray which is the time elapsed for ray to be intersect with sphere
	double t1 = (-b - sqrt(discriminant)) / (2 * a);
	double t2 = (-b + sqrt(discriminant)) / (2 * a);
	//if neither point not intersect
	if (t1 < MIN_TIME || t1 > MAX_TIME) { //p1 not intersect
		if (t2 < MIN_TIME || t2 > MAX_TIME) { //p2 not intersect
			return PtIntsect(-1, false);
		}
	}
	double actualtime = t1;
	//get intersection point
	bool isInside = false;
	//if first closer point not intersect but futher point intersected (then it must be inside point)
	Point intersect = rayOrgMoved + (rayDirScaled * t1);
	bool validintersect = true;
	//if this sphere has hole (check if point inside range)
	if (this->isHollow) {
		//check if first point exceed the range of sphere
		validintersect = this->validPoint(intersect);
		//if intersect is out of range (goes to the second intersect, if valid then point.inside will be true)
		if (!validintersect) {
			intersect = rayOrgMoved + (rayDirScaled * t2);
			validintersect = this->validPoint(intersect);
			if (!validintersect) return PtIntsect(-1, false);
			//if hollow sphere and point intersect with sphere on the second point
			else {
				actualtime = t2;
				isInside = true;
			}
		}
	}
	intersect *= this->radius; // scale back the direction
	intersect += this->centre; // transform back to world cooridnate system
	return PtIntsect(actualtime, isInside, intersect);
}

bool Ellipsoid::validPoint(const Point& point) {
	if (point.x > this->invPPart.x || point.x < this->invNPart.x) {
		return false;
	}
	if (point.y > this->invPPart.y || point.y < this->invNPart.y) {
		return false;
	}
	if (point.z > this->invPPart.z || point.z < this->invNPart.z) {
		return false;
	}
	return true;
}

//whether this object intersect with vector (for light source shadow)
bool Ellipsoid::isShadow(Ray& ray, double maxTime) {
	Vector rayDirScaled = ray.direction / this->radius; //first scale the direction
	Point rayOrgMoved = ray.origin - this->centre; //transform to Ellipsoid cooridnate system
	rayOrgMoved /= this->radius; //scaling to fit change of Ellipsoid to Sphere

	double a = rayDirScaled.lenSqr(); //get the square of length of ray
	double b = 2 * rayDirScaled.dot(rayOrgMoved);
	double c = rayOrgMoved.lenSqr() - 1;
	double discriminant = b * b - 4 * a*c;

	if (discriminant < 0) {
		return false;
	}
	//get root of ray which is the time elapsed for ray to be intersect with sphere
	double t1 = (-b - sqrt(discriminant)) / (2 * a);
	double t2 = (-b + sqrt(discriminant)) / (2 * a);

	if (t1 < MIN_TIME || t1 > maxTime) { //p1 not intersect
		if (t2 < MIN_TIME || t2 > maxTime) { //p2 not intersect
			return false;
		}
	}
	//if hallow
	//check if first intersection valid, if not then second, if all not then false, if either of one intersect then true
	if (this->isHollow) {
		Point intersect = rayOrgMoved + (rayDirScaled * t1);
		bool validintersect = this->validPoint(intersect);
		if (!validintersect) {
			intersect = rayOrgMoved + (rayDirScaled * t2);
			validintersect = this->validPoint(intersect);
			if (!validintersect) return false;
		}
	}
	return true;
}

Vector Ellipsoid::normal(double x, double y, double z, bool inside) {
	double nx = (x - this->centre.x) / (radius.x * radius.x);
	double ny = (y - this->centre.y) / (radius.y * radius.y);
	double nz = (z - this->centre.z) / (radius.z * radius.z);
	double len = sqrt(nx * nx + ny * ny + nz * nz);
	if (inside) return Vector(-nx / len, -ny / len, -nz / len);
	else return Vector(nx / len, ny / len, nz / len);
}

//get the normal unit vector
Vector Ellipsoid::normal(Point& pt, bool inside) {
	return this->normal(pt.x, pt.y, pt.z, inside);
}

Color Ellipsoid::getAmbient(Color ambColor) {
	return this->color * (ambColor * this->attribute.Ka);
}

Color Ellipsoid::getDeffuse(Color lightColor, Vector normal, Vector lightDir) {
	double dotProd = normal.dot(lightDir);
	if (dotProd < 0) dotProd = 0; //if dot product less than 0 (normal to light direction > 90 degree), then dot product = 0
	Color factor = lightColor * this->attribute.Kd * dotProd;
	return this->color * factor;
}

Color Ellipsoid::getSpecular(Color lightColor, Vector reflect, Vector rayDir) {
	double dotProd = reflect.dot(rayDir);
	if (dotProd < 0) dotProd = 0; //if dot product less than 0 (normal to ray direction > 90 degree), then dot product = 0
	Color factor = lightColor * this->attribute.Ks * pow(dotProd, this->attribute.n);
	return factor;
}
