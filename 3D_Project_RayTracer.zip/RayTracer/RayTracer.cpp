#include "Color.h"
#include "Ray.h"
#include "Ellipsoid.h"
#include "Vector.h"
#include "Light.h"

#include <vector>
#include <fstream>
#include <string>

std::vector<Ellipsoid> objs;
std::vector<Light> lights;
Color ambient; //store the ambient light intensity
Vector origin = Vector(0, 0, 0); //ray origin
unsigned char * pixels;
Color background;

//get pixel color based on ray and maximum bounce which ray can reflect
Color singleRayTrace(Ray& ray, int depth) {
	//determine if ray can intersect with object
	bool intsd = false; //if ray intersected with any of the object
	Ellipsoid intsObj; //object which intersected with ray
					   //for each ellipsoid object, get the intersection point and the object this ray intersect, and the bonceRay (which used for iteration of next bounce)
	PtIntsect intsect;
	bool inside = false;
	for (Ellipsoid obj : objs) {
		intsect = obj.intersect(ray);
		//if time intersection happen is smaller than end time of ray
		if (intsect.time > MIN_TIME && intsect.time < ray.endTime) {
			ray.endTime = intsect.time;
			intsd = true;
			inside = intsect.inside;
			intsObj = obj;
		}
	}
	Color result = Color(); //if no intersection happen or ray get it maximum bounce, color will be black
	result.isBg = true;
	//at this point intsect object is not reliable
	//if intersection happens, get color of this ray at start point of the ray
	//which affected by light source and reflected ray (result of singleRayTrace function)
	if (intsd && depth >= 0) {
		Point p = ray.getPoint(ray.endTime);
		Vector normal = intsObj.normal(p, inside); //get the normal vector for that point
		Vector reflected = normal * normal.dot(ray.direction * -1) * 2 + ray.direction;
		reflected.normalize();
		Ray bonceRay = Ray(p, reflected);
		result += intsObj.getAmbient(ambient); //get ambient color
		for (Light light : lights) {
			bool lightIntsd = false;
			Vector lightDir = light.position - p; //get light incident vector of intersection point
			double lightLen = lightDir.length(); //get light length
			lightDir.normalize(); //normalize the vector
			Vector lightrefl = normal * normal.dot(lightDir) * 2 - lightDir;
			lightrefl.normalize();
			//check if light vector intersect with any other object
			Ray lightRay = Ray(p, lightDir);
			for (Ellipsoid obj : objs) {
				//if (obj.intersect(lightRay).time > MIN_TIME) {
				if (obj.isShadow(lightRay, lightLen)) {
					lightIntsd = true;
					break;
				}
			}
			if (!lightIntsd) {
				result += intsObj.getDeffuse(light.color, normal, lightDir); //get diffuse color from light source
				result += intsObj.getSpecular(light.color, lightrefl, ray.direction * -1); //get specular color from light source
			}
		}
		Color reflOther = singleRayTrace(bonceRay, depth - 1);
		result += (reflOther * intsObj.attribute.Kr); //get color from reflected light of other object

		result.clamp();
		result.isBg = false;
	}
	return result;
}

// Output in P6 format, a binary file containing:
// P6
// ncolumns nrows
// Max colour value
// colours in binary format thus unreadable
void save_imageP6(int Width, int Height, const char* fname, unsigned char* pixels) {
	FILE *fp;
	const int maxVal = 255;

	printf("Saving image %s: %d x %d\n", fname, Width, Height);
	fp = fopen(fname, "wb");
	if (!fp) {
		printf("Unable to open file '%s'\n", fname);
		return;
	}
	fprintf(fp, "P6\n");
	fprintf(fp, "%d %d\n", Width, Height);
	fprintf(fp, "%d\n", maxVal);

	for (int j = 0; j < Height; j++) {
		fwrite(&pixels[j*Width * 3], 3, Width, fp);
	}

	fclose(fp);
}

// Output in P3 format, a text file containing:
// P3
// ncolumns nrows
// Max colour value (for us, and usually 255)
// r1 g1 b1 r2 g2 b2 .....
void save_imageP3(int Width, int Height, const char* fname, unsigned char* pixels) {
	FILE *fp;
	const int maxVal = 255;

	printf("Saving image %s: %d x %d\n", fname, Width, Height);
	fp = fopen(fname, "w");
	if (!fp) {
		printf("Unable to open file '%s'\n", fname);
		return;
	}
	fprintf(fp, "P3\n");
	fprintf(fp, "%d %d\n", Width, Height);
	fprintf(fp, "%d\n", maxVal);

	int k = 0;
	for (int j = 0; j < Height; j++) {

		for (int i = 0; i < Width; i++)
		{
			fprintf(fp, " %d %d %d", pixels[k], pixels[k + 1], pixels[k + 2]);
			k = k + 3;
		}
		fprintf(fp, "\n");
	}
	fclose(fp);
}

vector<string> split(const string &s, const string &seperator) {
	vector<string> result;
	bool extract = false; //whether the new term need to be extracted
	int start = 0, len = 0;
	for (int i = 0; i < s.length(); i++) {
		//if the character is not a white space character
		if (seperator.find(s[i]) == string::npos) {
			extract = true;
			len++;
		}
		//if the character is white space character
		else {
			//if first time reaches the white space (extract the word)
			if (extract) {
				result.push_back(s.substr(start, len));
				extract = false;
				len = 0;
			}
			start = i + 1;
		}
	}
	if (len > 0) {
		result.push_back(s.substr(start, len));
	}
	return result;
}

int main(int argc, char *argv[])
{
	//image property data
	char* fname3;
	double width, height, left, right, top, bottom, near = 1;
	//get all test data
	ifstream testdata(argv[1]);
	testdata.is_open(); //check if file is open, otherwise write message says file open failed
	string line;
	string seperator = " \t"; //space and tab are considered as white space
	vector<string> result;
	while (getline(testdata, line)) {
		//if line have data
		if (line.length() > 0) {
			result = split(line, seperator);
			if (result[0] == "NEAR") {
				near = stod(result[1]);
			}
			else if (result[0] == "SPHERE") {
				//sphere attribute data
				Coefficient attribute = Coefficient();
				attribute.Ka = stod(result[11]);
				attribute.Kd = stod(result[12]);
				attribute.Ks = stod(result[13]);
				attribute.Kr = stod(result[14]);
				attribute.n = stod(result[15]);
				//sphere data
				Point center = Point(stod(result[2]), stod(result[3]), stod(result[4]));
				Dimension radius = Dimension(stod(result[5]), stod(result[6]), stod(result[7]));
				Color color = Color(stod(result[8]), stod(result[9]), stod(result[10]));
				Ellipsoid obj = Ellipsoid(radius, center, color, attribute);
				//since near is minimum valid z value, and direction to negative z
				//so set sphere positive minimum z value (invalid range is on positive side)
				if (radius.z > -near - center.z) {
					obj.setHolPZ(-near);
				}
				objs.push_back(obj);
			}
			else if (result[0] == "LIGHT") {
				Point lightorg = Point(stod(result[2]), stod(result[3]), stod(result[4]));
				Color lightcolor = Color(stod(result[5]), stod(result[6]), stod(result[7]));
				Light light = Light(lightorg, lightcolor);
				lights.push_back(light);
			}
			else if (result[0] == "OUTPUT") {
				fname3 = new char[result[1].length()];
				strcpy(fname3, result[1].c_str());
			}
			else if (result[0] == "LEFT") {
				left = stod(result[1]);
			}
			else if (result[0] == "RIGHT") {
				right = stod(result[1]);
			}
			else if (result[0] == "TOP") {
				top = stod(result[1]);
			}
			else if (result[0] == "BOTTOM") {
				bottom = stod(result[1]);
			}
			else if (result[0] == "AMBIENT") {
				ambient = Color(stod(result[1]), stod(result[2]), stod(result[3]));
			}
			else if (result[0] == "BACK") {
				background = Color(stod(result[1]), stod(result[2]), stod(result[3]));
			}
			else if (result[0] == "RES") {
				width = stod(result[1]);
				height = stod(result[2]);
			}
		}
	}
	testdata.close();

	int width1 = (int) width;
	int height1 = (int) height;

	pixels = new unsigned char[3 * width1*height1];
	//get ratio between coordinate and pixel
	double coodXRatio = (right - left) / width;
	double coodLenY = (bottom - top) / height;

	//generate all rays
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			int pixelInd = (y * width + x) * 3;
			//I assume the origin is left bottom
			double rayX = x * coodXRatio + left;
			double rayY = y * coodLenY + top; //y start from top
											  //ray z will be always -1 (which is near value)
			Vector rayDir = Vector(rayX, rayY, -near);
			Ray ray = Ray(origin, rayDir);

//			if (x == 420 && y == 201) {
//				cout << "grate" << endl;
//
//			}

			Color pixel = singleRayTrace(ray, 3);
			//if it is background color
			if (pixel.isBg) pixel = background;

			//unsigned char temp1 = (unsigned char)(pixel.r * 255.0);
			//unsigned char temp2 = (unsigned char)(pixel.g * 255.0);
			//unsigned char temp3 = (unsigned char)(pixel.b * 255.0);

			pixels[pixelInd] = (unsigned char)(pixel.r * 255.0);
			pixels[pixelInd + 1] = (unsigned char)(pixel.g * 255.0);
			pixels[pixelInd + 2] = (unsigned char)(pixel.b * 255.0);
		}
	}

	save_imageP6(width, height, fname3, pixels);
	return 0;
}
