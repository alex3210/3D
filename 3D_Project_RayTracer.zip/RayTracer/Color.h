#pragma once
struct Color
{
	double r, g, b;
	bool isBg; //whether color is background color
	Color();
	Color(double value);
	Color(double r, double g, double b);
	~Color();

	void operator +=(const Color& color);
	void operator *=(double scalar);
	Color operator +(const Color& color);
	Color operator *(double scalar);
	Color operator *(const Color& color);
	void clamp();
};

Color::Color()
{
	this->r = 0;
	this->g = 0;
	this->b = 0;
	this->isBg = false;
}
Color::Color(double value)
{
	this->r = value;
	this->g = value;
	this->b = value;
	this->isBg = false;
}
Color::Color(double r, double g, double b)
{
	this->r = r;
	this->g = g;
	this->b = b;
	this->isBg = false;
}

void Color::operator +=(const Color& color)
{
	this->r += color.r;
	this->g += color.g;
	this->b += color.b;
}

void Color::operator *=(double scalar)
{
	this->r *= scalar;
	this->g *= scalar;
	this->b *= scalar;
}

Color Color::operator +(const Color& color)
{
	return Color(this->r + color.r, this->g + color.g, this->b * color.b);
}

Color Color::operator *(double scalar)
{
	return Color(this->r * scalar, this->g * scalar, this->b * scalar);
}

Color Color::operator *(const Color& color)
{
	return Color(this->r * color.r, this->g * color.g, this->b * color.b);
}

Color::~Color()
{
}

void Color::clamp() {
	if (this->r > 1) this->r = 1;
	if (this->g > 1) this->g = 1;
	if (this->b > 1) this->b = 1;
}
