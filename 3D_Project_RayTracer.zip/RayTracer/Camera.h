#pragma once
#include "Ray.h"

class Camera
{
public:
	Camera();
	virtual ~Camera();

	virtual Ray makeRay(Vector point) const = 0;
};



Camera::Camera()
{
}


Camera::~Camera()
{
}
