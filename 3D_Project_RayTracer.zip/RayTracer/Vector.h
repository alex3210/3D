#pragma once
#include<math.h>
//class of an 3D point or vector which commonly have
class Vector
{
public:
	double x, y, z;
	Vector();
	Vector(const Vector& dim);
	Vector(double x, double y, double z);
	Vector(double value);
	~Vector();

	//all the assignment operator defination
	void operator =(const Vector& dim);
	void operator +=(const Vector& dim);
	void operator -=(const Vector& dim);
	void operator *=(const Vector& dim);
	void operator /=(const Vector& dim);
	void operator *=(double scalar);
	void operator /=(double scalar);

	//all the arithmetic operator defination
	Vector operator +(const Vector& dim);
	Vector operator -(const Vector& dim);
	Vector operator *(const Vector& dim);
	Vector operator /(const Vector& dim);
	Vector operator *(double scalar);
	Vector operator /(double scalar);

	//method of all arithmetic operation with x,y,z as input
	void add(double x, double y, double z);
	void mult(double x, double y, double z);

	double lenSqr();
	double length();
	void normalize();

	//vector operation
	double dot(const Vector& v);
	Vector cross(const Vector& v);

};

Vector::Vector()
{
	this->x = 0.0;
	this->y = 0.0;
	this->z = 0.0;
}

Vector::Vector(const Vector& dim)
{
	this->x = dim.x;
	this->y = dim.y;
	this->z = dim.z;
}

Vector::Vector(double x, double y, double z)
{
	this->x = x;
	this->y = y;
	this->z = z;
}

Vector::Vector(double value)
{
	this->x = value;
	this->y = value;
	this->z = value;
}

Vector::~Vector()
{
}

//all assignment operator (change this object value)
void Vector::operator =(const Vector& dim)
{
	this->x = dim.x;
	this->y = dim.y;
	this->z = dim.z;
}

void Vector::operator +=(const Vector& dim)
{
	this->x += dim.x;
	this->y += dim.y;
	this->z += dim.z;
}

void Vector::operator -=(const Vector& dim)
{
	this->x -= dim.x;
	this->y -= dim.y;
	this->z -= dim.z;
}

void Vector::operator *=(const Vector& dim)
{
	this->x *= dim.x;
	this->y *= dim.y;
	this->z *= dim.z;
}

void Vector::operator /=(const Vector& dim)
{
	this->x /= dim.x;
	this->y /= dim.y;
	this->z /= dim.z;
}

void Vector::operator *=(double scalar)
{
	this->x *= scalar;
	this->y *= scalar;
	this->z *= scalar;
}

void Vector::operator /=(double scalar)
{
	this->x /= scalar;
	this->y /= scalar;
	this->z /= scalar;
}

//all operator which return new object and not change current object value
Vector Vector::operator +(const Vector& dim)
{
	return Vector(this->x + dim.x, this->y + dim.y, this->z + dim.z);
}

Vector Vector::operator -(const Vector& dim)
{
	return Vector(this->x - dim.x, this->y - dim.y, this->z - dim.z);
}

Vector Vector::operator *(const Vector& dim)
{
	return Vector(this->x * dim.x, this->y * dim.y, this->z * dim.z);
}

Vector Vector::operator /(const Vector& dim)
{
	return Vector(this->x / dim.x, this->y / dim.y, this->z / dim.z);
}

Vector Vector::operator *(double scalar)
{
	return Vector(this->x * scalar, this->y * scalar, this->z * scalar);
}

Vector Vector::operator /(double scalar)
{
	return Vector(this->x / scalar, this->y / scalar, this->z / scalar);
}

void Vector::add(double x, double y, double z) {
	this->x += x;
	this->y += y;
	this->z += z;
}

void Vector::mult(double x, double y, double z) {
	this->x *= x;
	this->y *= y;
	this->z *= z;
}

double Vector::lenSqr() {
	return this->x * this->x + this->y * this->y + this->z * this->z;
}

double Vector::length() {
	return sqrt(this->x * this->x + this->y * this->y + this->z * this->z);
}

//normalize this vector (change vector so that it has length of 1)
void Vector::normalize() {
	double length = this->length();
	this->x /= length;
	this->y /= length;
	this->z /= length;
}

double Vector::dot(const Vector& v)
{
	return this->x * v.x + this->y * v.y + this->z * v.z;
}

Vector Vector::cross(const Vector& v)
{
	double newX = this->y * v.z - this->z * v.y;
	double newY = this->z * v.x - this->x * v.z;
	double newZ = this->x * v.y - this->y * v.x;
	return Vector(newX, newY, newZ);
}

//point have no extra feature for dimension
typedef Vector Point;
typedef Vector Dimension;
