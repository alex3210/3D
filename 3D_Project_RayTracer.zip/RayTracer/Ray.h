#pragma once
#include "Color.h"
#include "Vector.h"

#define MIN_TIME 0.0001
// 'Infinite' distance
#define MAX_TIME 1.0e20

struct Ray
{
	Point origin; //which point does ray come from
	Vector direction; //direction vector of ray (length of this vector can be speed)
	double endTime; //time when this ray hit any of the object

	Ray();
	Ray(const Ray& r);
	Ray(const Point& origin, const Vector& direction);

	~Ray();

	Point getPoint(double time);
};

//create a ray with start point of (0,0,0) and directed on x asix
Ray::Ray()
{
	this->origin = Point(0, 0, 0);
	this->direction = Vector(1, 0, 0);
	this->endTime = MAX_TIME;
}

//copy a ray object
Ray::Ray(const Ray& r) {
	this->origin = Point(r.origin);
	this->direction = Vector(r.direction);
	this->direction.normalize();
	this->endTime = r.endTime;
}

//create a ray with given start point and direction
Ray::Ray(const Point& origin, const Vector& direction) {
	this->origin = Point(origin);
	this->direction = Vector(direction);
	this->direction.normalize();
	this->endTime = MAX_TIME;
}

Ray::~Ray()
{
}

Point Ray::getPoint(double time)
{
	return origin + (direction * time);
}
