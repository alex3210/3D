#pragma once
#include "Vector.h"
#include "Color.h"

struct Light
{
	Point position;
	Color color;
	Light(Point position, Color color);
	Light();
	~Light();
};

Light::Light()
{
	this->position = Point();
	this->color = Color();
}

Light::Light(Point position, Color color)
{
	this->position = position;
	this->color = color;
}

Light::~Light()
{
}
